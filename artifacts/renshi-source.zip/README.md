# 刃式

用直線方程對決的劍客遊戲。輸入數字是向對手揮劍，畫線是預測對手的氣來避開。

## 同事點樣跑

需要已安裝 Node.js 22。

```bash
npm install
npm run dev
```

然後用瀏覽器打開 http://localhost:8080

唔好把 `node_modules` 上傳去 GitHub。下載之後先自己 `npm install`。
